class WsdlsController < ApplicationController
	require 'lib/demos.rb'
	
	#GET NEEDED INFORMATION FOR PLUGIN SYSTEM AND LIBRARIES
	def index
		@plugins = Array.new
		xml_file_list = Dir.glob("app/*.xml")
		xml_file_list.each do |f|
			@plugins << Plugin.new(f)
		end
		@libraries = Library.find(:all)
		respond_to {|format| format.html}
	end
	
	#SAVES AN ABNF FILE FROM FORM INFORMATION
	def save_abnf_file
		begin
			file = AbnfFile.create_new_file(file_name, params[:library_id], session[:user_id])
			abnf_content = "First arg: #{params[:first_arg]}, second_arg: #{params[:second_arg]}"
			file.update_attributes(:content => abnf_content)
			session[:messages] = {:type => "ok", :msg => "File Saved!"}
		rescue Exceptions::MissingParameters
			session[:messages] = {:type => "err", :msg => "Missing file name!"}
		rescue Exceptions::InvalidLibraryId
			session[:messages] = {:type => "err", :msg => "Invalid Library id!"}			
		rescue
			session[:messages] = {:type => "err", :msg => "Generic error, please contact administrator"}
		end
		render :text => "true"
	end
	
end
